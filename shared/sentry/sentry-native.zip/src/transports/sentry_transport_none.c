#include "sentry_core.h"
#include "sentry_transport.h"

sentry_transport_t *
sentry__transport_new_default(void)
{
    return NULL;
}
